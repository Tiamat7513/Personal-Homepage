let slideIndex = 1;
showSlides(slideIndex);

// Function to show the current slide
function currentSlide(n) {
    showSlides(slideIndex = n);
}

// Function to display the slides
function showSlides(n) {
    let slides = document.getElementsByClassName("slide");
    let dots = document.getElementsByClassName("dot");
    if (n > slides.length) { slideIndex = 1 }
    if (n < 1) { slideIndex = slides.length }
    for (let i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }
    for (let i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndex - 1].style.display = "block";
    slides[slideIndex - 1].className += " fade";
    dots[slideIndex - 1].className += " active";
}

// Automatically switch slides every 5 seconds
setInterval(() => {
    slideIndex++;
    showSlides(slideIndex);
}, 5000);
